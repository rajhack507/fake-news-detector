# AI Fake News Detector

Streamlit app that estimates whether news content (text or video) is Fake or Real using a HuggingFace Transformer model, Whisper for speech-to-text, and optional Grok/Google fact-check integrations.

## Features
- Text input: headlines, articles, tweets
- Video upload: extract audio, transcribe with Whisper or SpeechRecognition, then classify
- Probability chart (Fake vs Real) and brief explanation
- Fact-check links and optional Grok (xAI) and Google Fact Check API integrations

## Quickstart
1. Create a virtual environment (recommended)
2. Install dependencies:
```bash
pip install -r requirements.txt
```
3. Run the app:
```bash
streamlit run app.py
```

## Training your own model
You can fine-tune a Transformer using `train.py`.

- From a CSV (must contain `text` and `label` columns, where label is 0/1 or Fake/Real):
```bash
python train.py --dataset csv --csv_path path/to/data.csv --text_col text --label_col label --model_name distilbert-base-uncased --epochs 3 --output_dir models/fake-news-model
```

- Using a built-in dataset (demo: `liar`, mapped to binary):
```bash
python train.py --dataset liar --model_name distilbert-base-uncased --epochs 3 --output_dir models/fake-news-model
```

After training, point the app to your model directory:
- Set an environment variable:
```bash
$env:FAKE_NEWS_MODEL="models/fake-news-model"
```
- Or enter it in the "Override model (optional)" field in the Video page.

## Integrations
- Grok (xAI):
  - Get an API key from xAI, then set:
  ```bash
  $env:GROK_API_KEY="YOUR_XAI_API_KEY"
  ```
  - In the sidebar Integrations section, provide the key. Enable "Use Grok (xAI)" toggles on Text/Video pages.

- Google Fact Check API (optional):
  - Enable the API in Google Cloud and create an API key, then set:
  ```bash
  $env:GOOGLE_FACT_CHECK_API_KEY="YOUR_API_KEY"
  ```
  - Enable the Google toggle on Text/Video pages.

## Environment Variables (optional)
- `FAKE_NEWS_MODEL`: HuggingFace model id or local path (e.g., `models/fake-news-model`).
- `WHISPER_MODEL`: Whisper model size (e.g., `base`, `small`). Default `base`.
- `GROK_API_KEY`: xAI Grok API key.
- `GROK_MODEL`: Grok model name (default `grok-2-latest`).
- `GOOGLE_FACT_CHECK_API_KEY`: Google Fact Check Tools API key.

## Notes
- First run downloads models from HuggingFace/Whisper; this may take a few minutes.
- For video transcription, `ffmpeg` must be installed or the app will use bundled `imageio-ffmpeg`.
- This project runs locally and is deployable on Streamlit Cloud or HuggingFace Spaces.
