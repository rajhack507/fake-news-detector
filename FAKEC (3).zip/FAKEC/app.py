import os
import tempfile
from typing import Tuple, Optional

import streamlit as st
import altair as alt
import pandas as pd
from dotenv import load_dotenv


load_dotenv()
newsapi_key = os.getenv("NEWSAPI_KEY", "68c668bcd57b4277aa33ca721adbfb0a")

from model import FakeNewsDetector
from utils import (
    extract_audio_from_video,
    transcribe_audio_to_text,
    clean_text,
    get_fact_check_links,
    fetch_news_from_api,
    get_news_sources,
)


# --------------------
# Streamlit Page Config
# --------------------
st.set_page_config(
    page_title="AI Fake News Detector",
    page_icon="📰",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Custom CSS (glassmorphism + minimal modern)
st.markdown(
    """
    <style>
    .main {
        background: linear-gradient(135deg, rgba(240,245,255,0.7) 0%, rgba(255,255,255,0.7) 100%);
        backdrop-filter: blur(10px);
    }
    .glass-card {
        background: rgba(255, 255, 255, 0.55);
        border-radius: 18px;
        padding: 24px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.08);
        border: 1px solid rgba(255,255,255,0.35);
    }
    .title {
        font-size: 38px;
        font-weight: 800;
        background: -webkit-linear-gradient(45deg, #0ea5e9, #6d28d9);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        margin-bottom: 8px;
    }
    .subtitle {
        color: #475569;
        font-size: 16px;
        margin-bottom: 24px;
    }
    .footer-note {
        color: #64748b;
        font-size: 12px;
    }
    .prob-label { font-weight: 600; }
    </style>
    """,
    unsafe_allow_html=True,
)

# --------------------
# Horizontal Navigation
# --------------------
st.markdown("""
<style>
.nav-container {
    background: linear-gradient(135deg, rgba(255,255,255,0.9) 0%, rgba(240,245,255,0.9) 100%);
    backdrop-filter: blur(10px);
    border-radius: 15px;
    padding: 10px;
    margin-bottom: 20px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
}
.nav-tabs {
    display: flex;
    gap: 10px;
    justify-content: center;
    flex-wrap: wrap;
}
.nav-tab {
    background: rgba(255,255,255,0.7);
    border: 2px solid transparent;
    border-radius: 10px;
    padding: 12px 20px;
    cursor: pointer;
    transition: all 0.3s ease;
    text-decoration: none;
    color: #374151;
    font-weight: 600;
    font-size: 14px;
}
.nav-tab:hover {
    background: rgba(59, 130, 246, 0.1);
    border-color: rgba(59, 130, 246, 0.3);
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(59, 130, 246, 0.2);
}
.nav-tab.active {
    background: linear-gradient(135deg, #3b82f6, #1d4ed8);
    color: white;
    border-color: #1d4ed8;
    box-shadow: 0 4px 15px rgba(59, 130, 246, 0.4);
}
.content-block {
    background: rgba(255, 255, 255, 0.8);
    border-radius: 15px;
    padding: 20px;
    margin: 15px 0;
    box-shadow: 0 5px 20px rgba(0,0,0,0.08);
    border: 1px solid rgba(255,255,255,0.3);
    transition: all 0.3s ease;
    cursor: pointer;
}
.content-block:hover {
    transform: translateY(-3px);
    box-shadow: 0 8px 25px rgba(0,0,0,0.12);
    border-color: rgba(59, 130, 246, 0.3);
}
.content-block.expanded {
    border-color: #3b82f6;
    box-shadow: 0 8px 25px rgba(59, 130, 246, 0.15);
}
</style>
""", unsafe_allow_html=True)

# Create horizontal navigation
st.markdown('<div class="nav-container">', unsafe_allow_html=True)
st.markdown('<div class="nav-tabs">', unsafe_allow_html=True)

# Navigation tabs
tabs = ["About", "Detect Text", "Detect Video", "Test Accuracy"]
page = st.radio("Navigation", tabs, index=1, horizontal=True, label_visibility="collapsed")

st.markdown('</div>', unsafe_allow_html=True)
st.markdown('</div>', unsafe_allow_html=True)

# Sidebar info
with st.sidebar:
    st.markdown("---")
    with st.expander("About this app"):
        st.write(
            "Detect whether a news item is fake or real using a fine-tuned Transformer model."
        )
        st.caption("Built with HuggingFace, Whisper, and Streamlit.")

# Lazy-load model to speed up initial UI render
@st.cache_resource(show_spinner=True)
def load_detector() -> FakeNewsDetector:
    return FakeNewsDetector()


def render_header():
    st.markdown('<div class="title">AI Fake News Detector</div>', unsafe_allow_html=True)
    st.markdown(
        '<div class="subtitle">Analyze text or video to estimate the probability of misinformation.</div>',
        unsafe_allow_html=True,
    )


def render_probability_chart(fake_prob: float, real_prob: float):
    df = pd.DataFrame({
        "Label": ["Fake", "Real"],
        "Probability": [fake_prob * 100.0, real_prob * 100.0],
    })
    chart = (
        alt.Chart(df)
        .mark_bar(cornerRadiusTopLeft=8, cornerRadiusTopRight=8)
        .encode(
            x=alt.X("Label", sort=None),
            y=alt.Y("Probability", scale=alt.Scale(domain=[0, 100])),
            color=alt.Color(
                "Label",
                scale=alt.Scale(range=["#ef4444", "#22c55e"]),
                legend=None,
            ),
            tooltip=["Label", alt.Tooltip("Probability", format=".2f")],
        )
        .properties(height=240)
    )
    st.altair_chart(chart, use_container_width=True)


def render_result_card(pred_label: str, fake_prob: float, real_prob: float, reason: str):
    with st.container():
        st.markdown('<div class="glass-card">', unsafe_allow_html=True)
        
        # Enhanced header with confidence indicator
        confidence = max(fake_prob, real_prob)
        if confidence >= 0.8:
            confidence_icon = "🟢"
            confidence_color = "#22c55e"
        elif confidence >= 0.65:
            confidence_icon = "🟡"
            confidence_color = "#f59e0b"
        else:
            confidence_icon = "🔴"
            confidence_color = "#ef4444"
        
        st.markdown(f"### {confidence_icon} Analysis Result")
        
        # Prediction with enhanced styling and probability display
        if pred_label == "Fake":
            st.markdown(f"**🔴 Prediction: {pred_label} News** ({fake_prob*100:.1f}% probability)")
            st.markdown(f"<div style='background-color: rgba(239, 68, 68, 0.1); padding: 10px; border-radius: 8px; border-left: 4px solid #ef4444;'>⚠️ This content shows characteristics of misinformation. Please verify with reliable sources.</div>", unsafe_allow_html=True)
        else:  # Real
            st.markdown(f"**🟢 Prediction: {pred_label} News** ({real_prob*100:.1f}% probability)")
            st.markdown(f"<div style='background-color: rgba(34, 197, 94, 0.1); padding: 10px; border-radius: 8px; border-left: 4px solid #22c55e;'>✅ This content appears to be from reliable sources. Still recommended to verify important news.</div>", unsafe_allow_html=True)
        
        # Show both probabilities for transparency
        st.markdown("**📊 Probability Breakdown:**")
        col1, col2 = st.columns(2)
        with col1:
            st.metric("Real News", f"{real_prob*100:.1f}%", delta=None)
        with col2:
            st.metric("Fake News", f"{fake_prob*100:.1f}%", delta=None)
        
        # Enhanced probability chart
        render_probability_chart(fake_prob, real_prob)
        
        # Detailed explanation
        st.markdown("**📊 Detailed Analysis**")
        st.markdown(reason)
        
        # Additional tips
        st.markdown("---")
        st.markdown("**💡 Tips for News Verification:**")
        st.markdown("""
        - Check multiple reliable news sources
        - Look for original sources and citations
        - Be wary of sensational headlines
        - Verify dates and locations
        - Check if the story appears on established news sites
        """)
        
        st.markdown("</div>", unsafe_allow_html=True)


def _render_sources_area(query_text: str):
    st.markdown("---")
    st.subheader("Fact-check sources")
    links = get_fact_check_links(query_text)
    st.write("Try these searches:")
    for label, url in links:
        st.write(f"- [{label}]({url})")


def handle_text_detection():
    render_header()

    # Unified input system
    with st.expander("📝 **News Input & Analysis**", expanded=True):
        # Input method selection
        input_mode = st.radio("Choose input method:", ["Manual Text", "Live News", "Both"], horizontal=True)
        
        # Manual text input (always available)
        if input_mode in ["Manual Text", "Both"]:
            st.markdown("**📄 Manual Text Input**")
            manual_text = st.text_area(
                "Enter news text (headline, article, tweet)",
                key="news_text",
                height=120,
                placeholder="Paste or type your news text here...",
            )
        
        # Live news input (always available)
        if input_mode in ["Live News", "Both"]:
            st.markdown("**📰 Live News Search**")
            # NewsAPI integration - using hardcoded API key
            if not newsapi_key:
                st.error("❌ NewsAPI key not found.")
            else:
                st.info("🔑 Using NewsAPI with configured key")
                
                # Basic search options
                col1, col2 = st.columns([2, 1])
                with col1:
                    search_query = st.text_input("Search query", placeholder="e.g., politics, technology, sports", key="search_query")
                with col2:
                    num_articles = st.number_input("Number of articles", min_value=1, max_value=20, value=3, key="num_articles")
                
                # Advanced options in expander
                with st.expander("Advanced News Search Options"):
                    col3, col4 = st.columns([1, 1])
                    with col3:
                        country = st.selectbox("Country", ["", "us", "gb", "ca", "au", "in", "de", "fr"], index=0, key="country")
                    with col4:
                        category = st.selectbox("Category", ["", "business", "entertainment", "health", "science", "sports", "technology"], index=0, key="category")
                    
                    col5, col6 = st.columns([1, 1])
                    with col5:
                        sources = st.text_input("Sources (comma-separated)", placeholder="e.g., bbc-news,cnn,reuters", key="sources")
                    with col6:
                        domains = st.text_input("Domains (comma-separated)", placeholder="e.g., bbc.co.uk,cnn.com", key="domains")
                    
                    col7, col8 = st.columns([1, 1])
                    with col7:
                        from_date = st.date_input("From date", value=None, key="from_date")
                    with col8:
                        to_date = st.date_input("To date", value=None, key="to_date")
                    
                    sort_by = st.selectbox("Sort by", ["publishedAt", "relevancy", "popularity"], index=0, key="sort_by")
                    
                    # Test API connection
                    if st.button("Test API Connection"):
                        with st.spinner("Testing API connection..."):
                            # Try a simple request
                            test_articles = fetch_news_from_api(newsapi_key, page_size=1)
                            if test_articles:
                                st.success("✅ API connection successful!")
                                st.write(f"Test article: {test_articles[0]['title'][:100]}...")
                            else:
                                st.error("❌ API connection failed. Check your API key.")
                    
                    # Show available sources
                    if st.button("Show Available Sources"):
                        with st.spinner("Loading sources..."):
                            sources_list = get_news_sources(newsapi_key, category=category if category else "", country=country if country else "")
                            if sources_list:
                                st.write("Available sources:")
                                for source in sources_list[:20]:  # Show first 20
                                    st.write(f"- {source['name']} ({source['id']}) - {source['category']} - {source['country']}")
                            else:
                                st.write("No sources found or API error.")
    
    # Main content block
    with st.container():
        st.markdown('<div class="content-block">', unsafe_allow_html=True)

        # Model settings in expandable block
        with st.expander("⚙️ **Model Settings**", expanded=False):
            col1, col2 = st.columns([1, 1])
            with col1:
                min_len = st.number_input("Minimum characters", value=30, min_value=0)
                precision = st.selectbox("Precision", ["fp32", "fp16", "bf16"], index=1)  # Default to fp16
            with col2:
                decision_mode = st.selectbox("Decision mode", ["balanced", "precision", "recall", "conservative"], index=0)  # Default to balanced
            
            # Model bias settings
            st.markdown("**Model Bias Settings**")
            col3, col4 = st.columns([1, 1])
            with col3:
                real_news_bias = st.selectbox("Real News Bias", ["None", "Low", "Medium", "High"], index=2, help="Higher bias increases likelihood of real news classification")
            with col4:
                confidence_threshold = st.selectbox("Confidence Display", ["Standard", "Detailed", "Conservative"], index=1, help="How detailed to show confidence information")
            
            # Fixed model parameters optimized for real news detection
            temperature = 0.8  # Slightly higher temperature for more balanced predictions
            zs_weight = 0.0  # Zero-shot blending weight (disabled)

        st.markdown("</div>", unsafe_allow_html=True)

    if st.button("Analyze", type="primary"):
        detector = load_detector()
        detector.precision = precision
        detector.decision_mode = decision_mode
        detector.temperature = float(temperature)
        detector.zero_shot_weight = float(zs_weight)
        
        # Apply real news bias
        if real_news_bias == "Low":
            detector.real_news_bias = 0.05
        elif real_news_bias == "Medium":
            detector.real_news_bias = 0.10
        elif real_news_bias == "High":
            detector.real_news_bias = 0.15
        else:
            detector.real_news_bias = 0.0

        # Handle different input modes
        if input_mode == "Manual Text":
            if not st.session_state.get("news_text"):
                st.warning("Please enter some text.")
                return

            text = clean_text(st.session_state["news_text"]) or ""
            if len(text) < min_len:
                st.warning("Text is too short to analyze. Please provide more context.")
                return

            with st.spinner("Analyzing text with Transformer model..."):
                result = detector.predict(text)

            render_result_card(
                result.label,
                result.fake_probability,
                result.real_probability,
                result.explanation,
            )

            _render_sources_area(text)
        
        elif input_mode == "Live News":
            # API key is now hardcoded, no need to check
            
            with st.spinner("Fetching news from NewsAPI..."):
                # Convert dates to string format if provided
                from_date_str = from_date.strftime("%Y-%m-%d") if from_date else ""
                to_date_str = to_date.strftime("%Y-%m-%d") if to_date else ""
                
                articles = fetch_news_from_api(
                    newsapi_key, 
                    query=search_query if search_query else "",
                    country=country if country else "",
                    category=category if category else "",
                    sources=sources if sources else "",
                    domains=domains if domains else "",
                    page_size=num_articles,
                    from_date=from_date_str,
                    to_date=to_date_str,
                    sort_by=sort_by
                )
            
            if not articles:
                st.error("No articles found. Check your API key and try different search terms.")
                st.info("💡 **Troubleshooting tips:**")
                st.write("- Verify your NewsAPI key is correct")
                st.write("- Try simpler search terms (e.g., 'politics', 'technology')")
                st.write("- Check if you have any advanced filters applied")
                st.write("- For free accounts, you can only access articles from the last 30 days")
                return
            
            st.success(f"Found {len(articles)} articles. Analyzing...")
            
            results = []
            for i, article in enumerate(articles):
                with st.spinner(f"Analyzing article {i+1}/{len(articles)}..."):
                    result = detector.predict(article["content"])
                    results.append({
                        "title": article["title"],
                        "source": article["source"],
                        "published": article["published"],
                        "url": article["url"],
                        "prediction": result.label,
                        "fake_prob": result.fake_probability,
                        "real_prob": result.real_probability,
                        "explanation": result.explanation
                    })
            
            # Display results
            st.markdown("---")
            st.subheader("Analysis Results")
            
            for result in results:
                with st.expander(f"{result['title'][:80]}... - {result['prediction']}"):
                    st.write(f"**Source:** {result['source']}")
                    st.write(f"**Published:** {result['published']}")
                    st.write(f"**Prediction:** {result['prediction']}")
                    
                    # Probability chart for this article
                    df = pd.DataFrame({
                        "Label": ["Fake", "Real"],
                        "Probability": [result['fake_prob'] * 100, result['real_prob'] * 100]
                    })
                    chart = (
                        alt.Chart(df)
                        .mark_bar(cornerRadiusTopLeft=8, cornerRadiusTopRight=8)
                        .encode(
                            x=alt.X("Label", sort=None),
                            y=alt.Y("Probability", scale=alt.Scale(domain=[0, 100])),
                            color=alt.Color(
                                "Label",
                                scale=alt.Scale(range=["#ef4444", "#22c55e"]),
                                legend=None,
                            ),
                        )
                        .properties(height=150)
                    )
                    st.altair_chart(chart, use_container_width=True)
                    
                    st.write(f"**Explanation:** {result['explanation']}")
                    if result['url']:
                        st.write(f"**Read more:** [Link]({result['url']})")
            
            # Summary statistics
            st.markdown("---")
            st.subheader("Summary")
            fake_count = sum(1 for r in results if r['prediction'] == 'Fake')
            real_count = sum(1 for r in results if r['prediction'] == 'Real')
            
            col_sum1, col_sum2 = st.columns(2)
            with col_sum1:
                st.metric("Fake", fake_count)
            with col_sum2:
                st.metric("Real", real_count)
        
        else:  # Both mode - analyze both manual text and live news
            all_results = []
            
            # Analyze manual text if provided
            if st.session_state.get("news_text"):
                text = clean_text(st.session_state["news_text"]) or ""
                if len(text) >= min_len:
                    with st.spinner("Analyzing manual text..."):
                        result = detector.predict(text)
                        all_results.append({
                            "title": "Manual Text Input",
                            "source": "User Input",
                            "published": "Now",
                            "url": "",
                            "prediction": result.label,
                            "fake_prob": result.fake_probability,
                            "real_prob": result.real_probability,
                            "explanation": result.explanation,
                            "content": text
                        })
            
            # Analyze live news if search query provided
            if search_query and newsapi_key:
                with st.spinner("Fetching and analyzing live news..."):
                    # Convert dates to string format if provided
                    from_date_str = from_date.strftime("%Y-%m-%d") if from_date else ""
                    to_date_str = to_date.strftime("%Y-%m-%d") if to_date else ""
                    
                    articles = fetch_news_from_api(
                        newsapi_key, 
                        query=search_query if search_query else "",
                        country=country if country else "",
                        category=category if category else "",
                        sources=sources if sources else "",
                        domains=domains if domains else "",
                        page_size=num_articles,
                        from_date=from_date_str,
                        to_date=to_date_str,
                        sort_by=sort_by
                    )
                    
                    if articles:
                        for i, article in enumerate(articles):
                            with st.spinner(f"Analyzing live news article {i+1}/{len(articles)}..."):
                                result = detector.predict(article["content"])
                                all_results.append({
                                    "title": article["title"],
                                    "source": article["source"],
                                    "published": article["published"],
                                    "url": article["url"],
                                    "prediction": result.label,
                                    "fake_prob": result.fake_probability,
                                    "real_prob": result.real_probability,
                                    "explanation": result.explanation,
                                    "content": article["content"]
                                })
            
            if not all_results:
                st.warning("Please provide either manual text or a search query to analyze.")
                return
            
            # Display combined results
            st.markdown("---")
            st.subheader("Combined Analysis Results")
            
            for result in all_results:
                with st.expander(f"{result['title'][:80]}... - {result['prediction']}"):
                    st.write(f"**Source:** {result['source']}")
                    st.write(f"**Published:** {result['published']}")
                    st.write(f"**Prediction:** {result['prediction']}")
                    
                    # Probability chart for this article
                    df = pd.DataFrame({
                        "Label": ["Fake", "Real"],
                        "Probability": [result['fake_prob'] * 100, result['real_prob'] * 100]
                    })
                    chart = (
                        alt.Chart(df)
                        .mark_bar(cornerRadiusTopLeft=8, cornerRadiusTopRight=8)
                        .encode(
                            x=alt.X("Label", sort=None),
                            y=alt.Y("Probability", scale=alt.Scale(domain=[0, 100])),
                            color=alt.Color(
                                "Label",
                                scale=alt.Scale(range=["#ef4444", "#22c55e"]),
                                legend=None,
                            ),
                        )
                        .properties(height=150)
                    )
                    st.altair_chart(chart, use_container_width=True)
                    
                    st.write(f"**Explanation:** {result['explanation']}")
                    if result['url']:
                        st.write(f"**Read more:** [Link]({result['url']})")
                    
                    # Show content for manual text
                    if result['source'] == "User Input":
                        st.write("**Content:**")
                        st.write(result['content'][:500] + ("..." if len(result['content']) > 500 else ""))
            
            # Summary statistics
            st.markdown("---")
            st.subheader("Summary")
            fake_count = sum(1 for r in all_results if r['prediction'] == 'Fake')
            real_count = sum(1 for r in all_results if r['prediction'] == 'Real')
            
            col_sum1, col_sum2 = st.columns(2)
            with col_sum1:
                st.metric("Fake", fake_count)
            with col_sum2:
                st.metric("Real", real_count)


def handle_video_detection():
    render_header()
    
    # Video upload in expandable block
    with st.expander("🎥 **Video Upload**", expanded=True):
        video_file = st.file_uploader("Upload a news video (mp4, mov, avi, mkv)", type=["mp4", "mov", "avi", "mkv"]) 
        model_name = st.text_input(
            "Override model (optional)",
            value=os.getenv("FAKE_NEWS_MODEL", ""),
            placeholder="e.g. mrm8488/bert-tiny-finetuned-fake-news-detection",
        )
        st.caption("Audio will be extracted and transcribed. Processing happens locally.")
    
    # Model settings in expandable block
    with st.expander("⚙️ **Model Settings**", expanded=False):
        col1, col2 = st.columns([1, 1])
        with col1:
            precision = st.selectbox("Precision", ["fp32", "fp16", "bf16"], index=1, key="vid_precision")  # Default to fp16
        with col2:
            decision_mode = st.selectbox("Decision mode", ["balanced", "precision", "recall", "conservative"], index=0, key="vid_decision")  # Default to balanced
        
        # Model bias settings for video
        st.markdown("**Model Bias Settings**")
        col3, col4 = st.columns([1, 1])
        with col3:
            real_news_bias = st.selectbox("Real News Bias", ["None", "Low", "Medium", "High"], index=2, key="vid_bias", help="Higher bias increases likelihood of real news classification")
        with col4:
            confidence_threshold = st.selectbox("Confidence Display", ["Standard", "Detailed", "Conservative"], index=1, key="vid_confidence", help="How detailed to show confidence information")
        
        # Fixed model parameters optimized for real news detection
        temperature = 0.8  # Slightly higher temperature for more balanced predictions
        zs_weight = 0.0  # Zero-shot blending weight (disabled)

    if st.button("Analyze Video", type="primary"):
        if not video_file:
            st.warning("Please upload a video file.")
            return

        with tempfile.TemporaryDirectory() as tmpdir:
            in_path = os.path.join(tmpdir, video_file.name)
            with open(in_path, "wb") as f:
                f.write(video_file.getbuffer())

            with st.spinner("Extracting audio from video..."):
                audio_path = extract_audio_from_video(in_path, tmpdir)

            with st.spinner("Transcribing audio to text (Whisper/SpeechRecognition)..."):
                transcript, stt_used = transcribe_audio_to_text(audio_path)

        if not transcript.strip():
            st.error("Could not transcribe any speech from the video.")
            return

        st.success(f"Transcription ready using {stt_used}.")
        detector = load_detector() if not model_name else FakeNewsDetector(model_name=model_name)
        detector.precision = precision
        detector.decision_mode = decision_mode
        detector.temperature = float(temperature)
        detector.zero_shot_weight = float(zs_weight)
        
        # Apply real news bias for video
        if real_news_bias == "Low":
            detector.real_news_bias = 0.05
        elif real_news_bias == "Medium":
            detector.real_news_bias = 0.10
        elif real_news_bias == "High":
            detector.real_news_bias = 0.15
        else:
            detector.real_news_bias = 0.0

        with st.spinner("Analyzing transcript with Transformer model..."):
            result = detector.predict(transcript)

        render_result_card(
            result.label,
            result.fake_probability,
            result.real_probability,
            result.explanation,
        )

        st.markdown("---")
        st.subheader("Transcript (first 1200 characters)")
        st.write(transcript[:1200] + ("..." if len(transcript) > 1200 else ""))

        _render_sources_area(transcript[:256])


def handle_accuracy_testing():
    render_header()
    
    # Test configuration in expandable block
    with st.expander("🧪 **Test Configuration**", expanded=True):
        st.markdown("Test your model's accuracy with known real and fake news samples.")
        
        # Test data samples
        test_samples = {
            "Real News Samples": [
                {
                    "text": "Scientists at MIT have developed a new method for detecting early-stage cancer using machine learning algorithms, according to a study published in Nature Medicine.",
                    "label": "Real",
                    "source": "Scientific Journal"
                },
                {
                    "text": "The Federal Reserve announced today that it will maintain current interest rates following its monthly policy meeting, citing stable economic indicators.",
                    "label": "Real", 
                    "source": "Financial News"
                },
                {
                    "text": "According to the World Health Organization, global vaccination rates have increased by 15% this year, with developing countries showing the most improvement.",
                    "label": "Real",
                    "source": "International Organization"
                }
            ],
            "Fake News Samples": [
                {
                    "text": "BREAKING: Doctors hate this one weird trick that cures cancer in 24 hours! Click here to learn the secret they don't want you to know!",
                    "label": "Fake",
                    "source": "Clickbait"
                },
                {
                    "text": "You won't believe what happened when this woman tried this miracle cure! 100% guaranteed to work or your money back!",
                    "label": "Fake",
                    "source": "Scam"
                },
                {
                    "text": "SHOCKING: The government is hiding the truth about aliens! Share this before they delete it! The mainstream media won't tell you this!",
                    "label": "Fake",
                    "source": "Conspiracy"
                }
            ]
        }
        
        # Test configuration
        col1, col2 = st.columns([1, 1])
        with col1:
            test_mode = st.selectbox("Test Mode", ["Quick Test (3 samples)", "Full Test (6 samples)", "Custom Test"], index=0)
        with col2:
            real_news_bias = st.selectbox("Real News Bias", ["None", "Low", "Medium", "High"], index=2, key="test_bias")
        
        if st.button("Run Accuracy Test", type="primary"):
            detector = load_detector()
            
            # Apply bias settings
            if real_news_bias == "Low":
                detector.real_news_bias = 0.05
            elif real_news_bias == "Medium":
                detector.real_news_bias = 0.10
            elif real_news_bias == "High":
                detector.real_news_bias = 0.15
            else:
                detector.real_news_bias = 0.0
            
            # Select test samples
            if test_mode == "Quick Test (3 samples)":
                samples = test_samples["Real News Samples"][:1] + test_samples["Fake News Samples"][:2]
            elif test_mode == "Full Test (6 samples)":
                samples = test_samples["Real News Samples"] + test_samples["Fake News Samples"]
            else:
                st.info("Custom test mode - add your own samples below")
                return
            
            # Run tests
            results = []
            correct_predictions = 0
            total_predictions = len(samples)
            
            with st.spinner("Running accuracy test..."):
                for i, sample in enumerate(samples):
                    result = detector.predict(sample["text"])
                    is_correct = result.label == sample["label"]
                    if is_correct:
                        correct_predictions += 1
                    
                    results.append({
                        "sample": sample,
                        "prediction": result,
                        "correct": is_correct
                    })
            
            # Calculate accuracy
            accuracy = (correct_predictions / total_predictions) * 100
            
            # Display results in expandable blocks
            with st.expander("📊 **Test Results Summary**", expanded=True):
                # Accuracy summary
                col1, col2, col3 = st.columns(3)
                with col1:
                    st.metric("Accuracy", f"{accuracy:.1f}%")
                with col2:
                    st.metric("Correct", f"{correct_predictions}/{total_predictions}")
                with col3:
                    st.metric("Real News Bias", real_news_bias)
            
            # Detailed results
            with st.expander("📋 **Detailed Results**", expanded=False):
                for i, result in enumerate(results):
                    sample = result["sample"]
                    prediction = result["prediction"]
                    is_correct = result["correct"]
                    
                    with st.expander(f"Test {i+1}: {sample['label']} News - {'✅ Correct' if is_correct else '❌ Incorrect'}"):
                        st.write(f"**Expected:** {sample['label']}")
                        st.write(f"**Predicted:** {prediction.label}")
                        st.write(f"**Source Type:** {sample['source']}")
                        st.write(f"**Confidence:** {max(prediction.fake_probability, prediction.real_probability)*100:.1f}%")
                        
                        # Show the text
                        st.write("**Sample Text:**")
                        st.write(sample["text"])
                        
                        # Show prediction details
                        st.write("**Model Analysis:**")
                        st.write(prediction.explanation)
            
            # Performance analysis
            with st.expander("📈 **Performance Analysis**", expanded=False):
                if accuracy >= 80:
                    st.success(f"🎉 Excellent performance! {accuracy:.1f}% accuracy indicates the model is working well.")
                elif accuracy >= 60:
                    st.warning(f"⚠️ Moderate performance. {accuracy:.1f}% accuracy suggests room for improvement.")
                else:
                    st.error(f"❌ Poor performance. {accuracy:.1f}% accuracy indicates the model needs adjustment.")
                
                # Recommendations
                st.markdown("**💡 Recommendations:**")
                if accuracy < 70:
                    st.write("- Try adjusting the Real News Bias setting")
                    st.write("- Check if the model parameters need tuning")
                    st.write("- Consider using more diverse training data")
                else:
                    st.write("- Model is performing well with current settings")
                    st.write("- Consider testing with more diverse samples")
                    st.write("- Monitor performance on different types of content")
        
        # Additional testing resources
        with st.expander("📚 **Additional Testing Resources**", expanded=False):
            st.markdown("**Reliable News Sources for Testing:**")
            st.markdown("""
            - **BBC News**: https://www.bbc.com/news
            - **Reuters**: https://www.reuters.com
            - **Associated Press**: https://apnews.com
            - **The Guardian**: https://www.theguardian.com
            - **NPR**: https://www.npr.org
            """)
            
            st.markdown("**Fact-Checking Organizations:**")
            st.markdown("""
            - **Snopes**: https://www.snopes.com (verified labels)
            - **FactCheck.org**: https://www.factcheck.org
            - **PolitiFact**: https://www.politifact.com
            - **AFP Fact Check**: https://factcheck.afp.com
            """)
            
            st.markdown("**Known Satire/Fake Sources:**")
            st.markdown("""
            - **The Onion**: https://www.theonion.com (satire)
            - **The Babylon Bee**: https://babylonbee.com (satire)
            - **Clickhole**: https://www.clickhole.com (satire)
            """)


# --------------------
# Router
# --------------------
if page == "About":
    render_header()
    
    with st.expander("ℹ️ **About This App**", expanded=True):
        st.markdown("""
        This app estimates whether content is likely fake or real using advanced AI technology.
        
        **Features:**
        - 🤖 **AI-Powered Detection**: Uses a fine-tuned Transformer model for fake news detection
        - 🎤 **Video Analysis**: Extracts audio and transcribes speech using Whisper
        - 📰 **Live News Integration**: Fetches and analyzes current news from NewsAPI
        - ⚙️ **Customizable Settings**: Adjust model bias and confidence thresholds
        - 🧪 **Accuracy Testing**: Built-in testing tools to evaluate model performance
        
        **Technology Stack:**
        - HuggingFace Transformers
        - OpenAI Whisper
        - Streamlit
        - NewsAPI
        
        **Important Note:** Always verify with reliable sources before sharing news.
        """)
    
    with st.expander("🚀 **Getting Started**", expanded=False):
        st.markdown("""
        **Quick Start Guide:**
        1. **Detect Text**: Paste news text or use live news from NewsAPI
        2. **Detect Video**: Upload a video file for audio transcription and analysis
        3. **Test Accuracy**: Use built-in test samples to evaluate model performance
        4. **Adjust Settings**: Fine-tune model bias and confidence levels
        
        **Tips for Best Results:**
        - Provide complete news articles when possible
        - Use the Real News Bias setting to adjust sensitivity
        - Test with known samples to understand model behavior
        - Always cross-reference with multiple reliable sources
        """)
    
    with st.expander("📊 **Model Information**", expanded=False):
        st.markdown("""
        **Model Details:**
        - **Base Model**: BERT-based transformer fine-tuned for fake news detection
        - **Precision**: Supports fp32, fp16, and bf16 for optimal performance
        - **Decision Modes**: Balanced, Precision, Recall, and Conservative
        - **Real News Bias**: Configurable bias toward real news classification
        - **Temperature Scaling**: Adjustable confidence calibration
        
        **Performance:**
        - Optimized for real-world news content
        - Handles both short headlines and long articles
        - Supports multiple languages (primary: English)
        - Local processing for privacy
        """)

elif page == "Detect Text":
    handle_text_detection()

elif page == "Detect Video":
    handle_video_detection()

elif page == "Test Accuracy":
    handle_accuracy_testing()

