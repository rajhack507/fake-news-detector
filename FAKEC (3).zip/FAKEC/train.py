import argparse
import os
from typing import Dict, Any

import numpy as np
from datasets import load_dataset, DatasetDict
from transformers import (
    AutoTokenizer,
    AutoModelForSequenceClassification,
    Trainer,
    TrainingArguments,
    DataCollatorWithPadding,
    set_seed,
)
import evaluate


def load_data_from_csv(csv_path: str, text_col: str = "text", label_col: str = "label", test_size: float = 0.1) -> DatasetDict:
    data = load_dataset("csv", data_files={"data": csv_path})
    ds = data["data"]

    # Validate columns
    cols = set(ds.column_names)
    if text_col not in cols or label_col not in cols:
        raise ValueError(f"CSV must contain columns '{text_col}' and '{label_col}'. Found: {sorted(cols)}")

    # Map labels to integers if needed
    def normalize_labels(example: Dict[str, Any]):
        label = example[label_col]
        if isinstance(label, str):
            l = label.strip().lower()
            if l in ["fake", "false", "0", "no"]:
                example["labels"] = 0
            elif l in ["real", "true", "1", "yes"]:
                example["labels"] = 1
            else:
                # default unknown string to 0
                example["labels"] = 0
        else:
            example["labels"] = int(label)
        example["text"] = str(example[text_col])
        return example

    ds = ds.map(normalize_labels)
    # Keep only required columns
    keep = {"text", "labels"}
    remove_cols = [c for c in ds.column_names if c not in keep]
    ds = ds.remove_columns(remove_cols)

    split = ds.train_test_split(test_size=test_size, seed=42, stratify_by_column="labels")
    return DatasetDict(train=split["train"], validation=split["test"])


def load_builtin_dataset(name: str = "liar") -> DatasetDict:
    # For demo: use the LIAR dataset; map to binary (True=1, False=0; others -> 0)
    ds = load_dataset(name)

    def map_liar(example):
        text = example.get("statement") or example.get("text") or ""
        label = example.get("label", 0)
        # LIAR labels: 0: pants-fire, 1: false, 2: barely-true, 3: half-true, 4: mostly-true, 5: true
        # Map to binary: {0,1,2} -> 0 (fake-ish), {3,4,5} -> 1 (real-ish)
        try:
            bin_label = 1 if int(label) >= 3 else 0
        except Exception:
            bin_label = 0
        return {"text": text, "labels": bin_label}

    train = ds["train"].map(map_liar, remove_columns=ds["train"].column_names)
    val = ds["validation"].map(map_liar, remove_columns=ds["validation"].column_names)
    return DatasetDict(train=train, validation=val)


def main():
    parser = argparse.ArgumentParser(description="Fine-tune a Transformer for Fake News detection")
    parser.add_argument("--output_dir", type=str, default="models/fake-news-model", help="Where to save the model")
    parser.add_argument("--model_name", type=str, default="distilbert-base-uncased", help="Base model name")
    parser.add_argument("--dataset", type=str, choices=["csv", "liar"], default="csv", help="Dataset source")
    parser.add_argument("--csv_path", type=str, default="", help="Path to CSV when dataset=csv")
    parser.add_argument("--text_col", type=str, default="text", help="Text column for CSV")
    parser.add_argument("--label_col", type=str, default="label", help="Label column for CSV (0/1 or Fake/Real)")
    parser.add_argument("--epochs", type=int, default=3, help="Training epochs")
    parser.add_argument("--batch_size", type=int, default=16, help="Per-device batch size")
    parser.add_argument("--lr", type=float, default=5e-5, help="Learning rate")
    parser.add_argument("--weight_decay", type=float, default=0.01, help="Weight decay")
    parser.add_argument("--warmup_ratio", type=float, default=0.06, help="Warmup ratio")
    parser.add_argument("--seed", type=int, default=42, help="Random seed")
    args = parser.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)
    set_seed(args.seed)

    # Load dataset
    if args.dataset == "csv":
        if not args.csv_path:
            raise ValueError("--csv_path is required when --dataset=csv")
        dsd = load_data_from_csv(args.csv_path, text_col=args.text_col, label_col=args.label_col)
    else:
        dsd = load_builtin_dataset("liar")

    # Tokenizer and model
    tokenizer = AutoTokenizer.from_pretrained(args.model_name)
    model = AutoModelForSequenceClassification.from_pretrained(
        args.model_name,
        num_labels=2,
        id2label={0: "fake", 1: "real"},
        label2id={"fake": 0, "real": 1},
    )

    def tokenize_fn(batch):
        return tokenizer(batch["text"], truncation=True, max_length=512)

    dsd = DatasetDict(
        train=dsd["train"].map(tokenize_fn, batched=True),
        validation=dsd["validation"].map(tokenize_fn, batched=True),
    )

    data_collator = DataCollatorWithPadding(tokenizer)

    accuracy = evaluate.load("accuracy")
    f1 = evaluate.load("f1")

    def compute_metrics(eval_pred):
        # Supports both tuple and EvalPrediction
        if isinstance(eval_pred, tuple):
            logits, labels = eval_pred
        else:
            logits, labels = eval_pred.predictions, eval_pred.label_ids
        preds = np.argmax(logits, axis=-1)
        return {
            "accuracy": accuracy.compute(predictions=preds, references=labels)["accuracy"],
            "f1": f1.compute(predictions=preds, references=labels)["f1"],
        }

    training_args = TrainingArguments(
        output_dir=args.output_dir,
        evaluation_strategy="epoch",
        save_strategy="epoch",
        learning_rate=args.lr,
        per_device_train_batch_size=args.batch_size,
        per_device_eval_batch_size=args.batch_size,
        num_train_epochs=args.epochs,
        weight_decay=args.weight_decay,
        warmup_ratio=args.warmup_ratio,
        logging_steps=50,
        load_best_model_at_end=True,
        metric_for_best_model="f1",
        report_to=[],
        seed=args.seed,
    )

    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=dsd["train"],
        eval_dataset=dsd["validation"],
        tokenizer=tokenizer,
        data_collator=data_collator,
        compute_metrics=compute_metrics,
    )

    trainer.train()
    trainer.save_model(args.output_dir)
    tokenizer.save_pretrained(args.output_dir)
    print(f"Model saved to: {args.output_dir}")


if __name__ == "__main__":
    main()
