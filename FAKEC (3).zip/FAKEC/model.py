from dataclasses import dataclass
from typing import Optional, Tuple, Dict, List
import os

import torch
import torch.nn.functional as F
from transformers import (
    AutoTokenizer,
    AutoModelForSequenceClassification,
    pipeline,
)


@dataclass
class PredictionResult:
    label: str
    fake_probability: float
    real_probability: float
    explanation: str


class FakeNewsDetector:
    """
    Transformer-based Fake News detector with:
    - Long-text chunking aggregation
    - Abstention when confidence is low
    - Numeric precision control (fp32/fp16/bf16)
    - Decision modes to bias towards precision/recall or conservative abstention
    - Temperature scaling and optional zero-shot ensemble blending
    """

    def __init__(self, model_name: Optional[str] = None, device: Optional[str] = None):
        self.model_name = model_name or os.getenv(
            "FAKE_NEWS_MODEL",
            "mrm8488/bert-tiny-finetuned-fake-news-detection",
        )
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")

        # Note: Abstention thresholds removed - model now always makes a decision

        # Chunking config
        self.chunk_max_tokens: int = int(os.getenv("FAKE_NEWS_CHUNK_MAX_TOKENS", "256"))
        self.chunk_overlap_tokens: int = int(os.getenv("FAKE_NEWS_CHUNK_OVERLAP", "32"))

        # Numeric precision: one of fp32, fp16, bf16
        self.precision: str = os.getenv("FAKE_NEWS_PRECISION", "fp32").lower()

        # Decision mode: balanced | precision | recall | conservative
        self.decision_mode: str = os.getenv("FAKE_NEWS_DECISION_MODE", "balanced").lower()

        # Temperature scaling (>=0.1). 1.0 = no change
        self.temperature: float = float(os.getenv("FAKE_NEWS_TEMPERATURE", "1.0"))

        # Zero-shot ensemble weight (0..1). 0 disables blending
        self.zero_shot_weight: float = float(os.getenv("FAKE_NEWS_ZS_WEIGHT", "0.0"))
        
        # Real news bias (0..1). Higher values increase likelihood of real news classification
        self.real_news_bias: float = float(os.getenv("FAKE_NEWS_REAL_BIAS", "0.0"))

        self._tokenizer = None
        self._model = None
        self._zshot = None
        self._id2label: Dict[int, str] = {}
        self._load_model()

    def _get_autocast_dtype(self):
        if self.device != "cuda":
            return None
        if self.precision == "fp16":
            return torch.float16
        if self.precision == "bf16":
            return torch.bfloat16
        return None

    def _load_model(self) -> None:
        try:
            self._tokenizer = AutoTokenizer.from_pretrained(self.model_name)
            self._model = AutoModelForSequenceClassification.from_pretrained(self.model_name)
            self._model.to(self.device)
            self._id2label = {int(i): str(lab).lower() for i, lab in self._model.config.id2label.items()}
        except Exception:
            self._tokenizer = None
            self._model = None
            self._zshot = pipeline(
                "zero-shot-classification",
                model="facebook/bart-large-mnli",
                device=0 if self.device == "cuda" else -1,
            )

    @staticmethod
    def _heuristic_explanation(text: str, fake_prob: float, real_prob: float) -> str:
        lowered = text.lower()
        signals_fake = [
            "you won't believe",
            "shocking",
            "miracle",
            "cure",
            "breaking",
            "secret",
            "share before they delete",
            "100% guaranteed",
            "doctors hate",
            "one weird trick",
            "click here",
            "limited time",
        ]
        signals_real = [
            "according to",
            "reported by",
            "researchers",
            "data shows",
            "study",
            "source",
            "official",
            "journal",
            "published",
            "peer-reviewed",
            "investigation",
            "analysis",
        ]
        fake_hits = [w for w in signals_fake if w in lowered]
        real_hits = [w for w in signals_real if w in lowered]

        # Determine confidence level
        confidence = max(fake_prob, real_prob)
        if confidence >= 0.8:
            confidence_level = "High"
        elif confidence >= 0.65:
            confidence_level = "Medium"
        else:
            confidence_level = "Low"

        base = f"**Confidence Level: {confidence_level}** ({confidence*100:.1f}%)\n\n"
        
        if fake_prob > real_prob:
            base += f"🔴 **Fake News** ({fake_prob*100:.1f}% probability)\n"
            base += f"🟢 **Real News** ({real_prob*100:.1f}% probability)\n\n"
            if fake_hits:
                base += f"⚠️ Detected suspicious language patterns: {', '.join(fake_hits[:3])}\n"
            base += "💡 **Recommendation:** Verify with multiple reliable sources before sharing."
        else:
            base += f"🟢 **Real News** ({real_prob*100:.1f}% probability)\n"
            base += f"🔴 **Fake News** ({fake_prob*100:.1f}% probability)\n\n"
            if real_hits:
                base += f"✅ Contains credible indicators: {', '.join(real_hits[:3])}\n"
            base += "💡 **Recommendation:** Still verify with independent sources for important news."
        
        base += "\n\n📚 **Always cross-check important news with multiple trusted sources.**"
        return base

    @staticmethod
    def _bucket_probabilities(label_to_prob: Dict[str, float]) -> Tuple[float, float]:
        fake_aliases = {
            "fake", "false", "misinformation", "disinformation", "hoax", "rumor",
            "not real", "scam", "clickbait", "unreliable", "fabricated"
        }
        real_aliases = {
            "real", "true", "reliable", "credible", "authentic", "genuine",
            "not fake", "legit", "factual", "verified"
        }
        fake_prob = 0.0
        real_prob = 0.0
        for label, prob in label_to_prob.items():
            l = label.lower()
            if l in fake_aliases:
                fake_prob += prob
                continue
            if l in real_aliases:
                real_prob += prob
                continue
            if any(tok in l for tok in ["fake", "false", "misinfo", "disinfo", "hoax", "rumor", "clickbait", "fabricat"]):
                fake_prob += prob
                continue
            if any(tok in l for tok in ["true", "real", "authentic", "reliable", "credible", "verified", "factual"]):
                real_prob += prob
                continue
        if fake_prob == 0.0 and real_prob == 0.0:
            return 0.5, 0.5
        total = fake_prob + real_prob
        return fake_prob / total, real_prob / total

    def _apply_decision_mode(self, fake_prob: float, real_prob: float) -> Tuple[float, float]:
        if self.decision_mode == "precision":
            fake_prob *= 0.9
            real_prob *= 1.05
        elif self.decision_mode == "recall":
            fake_prob *= 1.05
            real_prob *= 0.95
        elif self.decision_mode == "conservative":
            # Conservative mode: slightly favor real news
            fake_prob *= 0.95
            real_prob *= 1.05
        
        # Apply real news bias
        if self.real_news_bias > 0:
            # Reduce fake probability and increase real probability
            fake_prob *= (1.0 - self.real_news_bias)
            real_prob *= (1.0 + self.real_news_bias)
            
            # Normalize probabilities
            total = fake_prob + real_prob
            if total > 0:
                fake_prob = fake_prob / total
                real_prob = real_prob / total
        
        return fake_prob, real_prob

    def _softmax_with_temperature(self, logits: torch.Tensor) -> torch.Tensor:
        temp = max(0.1, float(self.temperature))
        return F.softmax(logits / temp, dim=-1)

    def _predict_with_native_model_single(self, text: str) -> Tuple[str, float, float]:
        assert self._tokenizer is not None and self._model is not None
        enc = self._tokenizer(
            text,
            return_tensors="pt",
            truncation=True,
            max_length=512,
        )
        enc = {k: v.to(self.device) for k, v in enc.items()}
        autocast_dtype = self._get_autocast_dtype()
        if autocast_dtype is not None:
            with torch.autocast(device_type="cuda", dtype=autocast_dtype):
                outputs = self._model(**enc)
        else:
            with torch.no_grad():
                outputs = self._model(**enc)
        logits = outputs.logits.squeeze(0)
        probs = self._softmax_with_temperature(logits)
        label_to_prob: Dict[str, float] = {}
        for i, p in enumerate(probs.tolist()):
            label = self._id2label.get(i, str(i))
            label_to_prob[label] = float(p)
        fake_prob, real_prob = self._bucket_probabilities(label_to_prob)
        fake_prob, real_prob = self._apply_decision_mode(fake_prob, real_prob)
        pred_label = "Fake" if fake_prob >= real_prob else "Real"
        return pred_label, fake_prob, real_prob

    def _chunk_text(self, text: str) -> List[str]:
        if self._tokenizer is None:
            return [text]
        tokens = self._tokenizer(text, add_special_tokens=False)["input_ids"]
        if len(tokens) <= self.chunk_max_tokens:
            return [text]
        chunks = []
        start = 0
        while start < len(tokens):
            end = start + self.chunk_max_tokens
            token_slice = tokens[start:end]
            chunk_text = self._tokenizer.decode(token_slice, skip_special_tokens=True)
            chunks.append(chunk_text)
            if end >= len(tokens):
                break
            start = end - self.chunk_overlap_tokens
            if start < 0:
                start = 0
        return chunks

    def _predict_with_native_model(self, text: str) -> Tuple[str, float, float]:
        chunks = self._chunk_text(text)
        if len(chunks) == 1:
            return self._predict_with_native_model_single(chunks[0])
        fake_sum = 0.0
        real_sum = 0.0
        for ch in chunks:
            _, fp, rp = self._predict_with_native_model_single(ch)
            fake_sum += fp
            real_sum += rp
        fake_prob = fake_sum / len(chunks)
        real_prob = real_sum / len(chunks)
        fake_prob, real_prob = self._apply_decision_mode(fake_prob, real_prob)
        label = "Fake" if fake_prob >= real_prob else "Real"
        return label, fake_prob, real_prob

    def _predict_with_zero_shot(self, text: str) -> Tuple[str, float, float]:
        hypothesis_template = "This statement is {}."
        out = self._zshot(
            text,
            candidate_labels=["fake", "real"],
            hypothesis_template=hypothesis_template,
        )
        mapping = {lab.lower(): float(score) for lab, score in zip(out["labels"], out["scores"])}
        fake_score = mapping.get("fake", 0.5)
        real_score = mapping.get("real", 0.5)
        s = fake_score + real_score
        if s == 0:
            fake_score, real_score = 0.5, 0.5
        else:
            fake_score, real_score = fake_score / s, real_score / s
        fake_score, real_score = self._apply_decision_mode(fake_score, real_score)
        return ("Fake" if fake_score >= real_score else "Real", fake_score, real_score)

    def _blend_with_zero_shot(self, text: str, native_probs: Tuple[float, float]) -> Tuple[float, float]:
        w = min(max(self.zero_shot_weight, 0.0), 1.0)
        if self._zshot is None or w <= 0.0:
            return native_probs
        _, zf, zr = self._predict_with_zero_shot(text)
        nf, nr = native_probs
        bf = (1 - w) * nf + w * zf
        br = (1 - w) * nr + w * zr
        s = bf + br
        if s == 0:
            return 0.5, 0.5
        return bf / s, br / s

    def _apply_abstention(self, fake_prob: float, real_prob: float) -> Optional[PredictionResult]:
        # Always make a decision - no more uncertain classification
        # The model will always choose between real and fake based on probabilities
        return None

    def predict(self, text: str) -> PredictionResult:
        text = (text or "").strip()
        if not text:
            return PredictionResult("Unknown", 0.5, 0.5, "Empty input.")

        if self._model is not None and self._tokenizer is not None:
            _, nf, nr = self._predict_with_native_model(text)
        else:
            _, nf, nr = self._predict_with_zero_shot(text)

        # Optionally blend with zero-shot
        fake_prob, real_prob = self._blend_with_zero_shot(text, (nf, nr))

        # Always make a decision - no abstention
        # Choose the label with higher probability
        label = "Fake" if fake_prob > real_prob else "Real"
        explanation = self._heuristic_explanation(text, fake_prob, real_prob)
        return PredictionResult(label=label, fake_probability=fake_prob, real_probability=real_prob, explanation=explanation)
