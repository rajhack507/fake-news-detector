import os
import re
import subprocess
from typing import List, Tuple, Dict, Optional


def extract_audio_from_video(video_path: str, workdir: str) -> str:
    """Extract audio track from video to a WAV file and return its path.
    Tries MoviePy first; then uses imageio-ffmpeg bundled binary; then ffmpeg-python.
    """
    audio_out = os.path.join(workdir, "extracted_audio.wav")

    # Try MoviePy (preferred for simplicity)
    try:
        from moviepy.editor import VideoFileClip  # type: ignore
        with VideoFileClip(video_path) as clip:
            clip.audio.write_audiofile(
                audio_out,
                fps=16000,
                codec="pcm_s16le",
                verbose=False,
                logger=None,
            )
        return audio_out
    except Exception:
        pass

    # Fallback 1: use bundled ffmpeg via imageio-ffmpeg
    try:
        import imageio_ffmpeg  # type: ignore
        ffmpeg_bin = imageio_ffmpeg.get_ffmpeg_exe()
        cmd = [
            ffmpeg_bin,
            "-y",
            "-i",
            video_path,
            "-ac",
            "1",
            "-ar",
            "16000",
            audio_out,
        ]
        subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True)
        return audio_out
    except Exception:
        pass

    # Fallback 2: use ffmpeg-python (requires system ffmpeg on PATH)
    try:
        import ffmpeg  # type: ignore
        (
            ffmpeg
            .input(video_path)
            .output(audio_out, ac=1, ar=16000, f="wav")
            .overwrite_output()
            .run(quiet=True)
        )
        return audio_out
    except Exception as e:
        raise RuntimeError(
            "Failed to extract audio. Install MoviePy or ensure ffmpeg is available. Try: pip install moviepy imageio-ffmpeg ffmpeg-python"
        ) from e


def _transcribe_with_whisper(audio_path: str) -> Tuple[str, str]:
    try:
        import whisper  # type: ignore
        model_name = os.getenv("WHISPER_MODEL", "base")
        model = whisper.load_model(model_name)
        res = model.transcribe(audio_path)
        return res.get("text", "").strip(), f"Whisper ({model_name})"
    except Exception:
        return "", "Whisper failed"


def _transcribe_with_speech_recognition(audio_path: str) -> Tuple[str, str]:
    try:
        import speech_recognition as sr  # type: ignore
        recognizer = sr.Recognizer()
        with sr.AudioFile(audio_path) as source:
            audio = recognizer.record(source)
        text = recognizer.recognize_google(audio)
        return text, "SpeechRecognition (Google)"
    except Exception:
        return "", "SpeechRecognition failed"


def transcribe_audio_to_text(audio_path: str) -> Tuple[str, str]:
    """
    Try Whisper first (local), then fall back to SpeechRecognition (Google).
    Returns (transcript, engine_used).
    """
    text, engine = _transcribe_with_whisper(audio_path)
    if text:
        return clean_text(text), engine
    text, engine = _transcribe_with_speech_recognition(audio_path)
    return clean_text(text), engine


def clean_text(text: str) -> str:
    text = (text or "").strip()
    text = re.sub(r"\s+", " ", text)
    return text


def fetch_news_from_api(api_key: str, query: str = "", country: str = "us", category: str = "", 
                       sources: str = "", domains: str = "", page_size: int = 10, 
                       from_date: str = "", to_date: str = "", sort_by: str = "publishedAt") -> List[Dict]:
    """Fetch news articles from NewsAPI using the official client with full feature support."""
    try:
        from newsapi import NewsApiClient
        
        # Initialize the client
        newsapi = NewsApiClient(api_key=api_key)
        
        # Debug: Print parameters
        print(f"NewsAPI Request - Query: '{query}', Country: '{country}', Category: '{category}', Sources: '{sources}', Domains: '{domains}'")
        
        # Fetch articles based on input
        response = None
        
        if query or sources or domains:
            # Use everything endpoint for search queries, sources, or domains
            params = {
                'language': 'en',
                'sort_by': sort_by,
                'page_size': min(page_size, 100)
            }
            
            if query:
                params['q'] = query
            if sources:
                params['sources'] = sources
            if domains:
                params['domains'] = domains
            if from_date:
                params['from_param'] = from_date
            if to_date:
                params['to'] = to_date
                
            print(f"Using get_everything with params: {params}")
            response = newsapi.get_everything(**params)
            
            # If everything endpoint fails and we have a query, try top headlines as fallback
            if response.get("status") == "error" and query:
                print("Everything endpoint failed, trying top headlines as fallback...")
                fallback_params = {'page_size': min(page_size, 100)}
                if country:
                    fallback_params['country'] = country
                if category:
                    fallback_params['category'] = category
                response = newsapi.get_top_headlines(**fallback_params)
        else:
            # Use top headlines for general news
            params = {
                'page_size': min(page_size, 100)
            }
            
            if country:
                params['country'] = country
            if category:
                params['category'] = category
            if sources:
                params['sources'] = sources
                
            print(f"Using get_top_headlines with params: {params}")
            response = newsapi.get_top_headlines(**params)
        
        print(f"NewsAPI Response Status: {response.get('status')}")
        print(f"Total Results: {response.get('totalResults', 0)}")
        
        # Check for API errors
        if response.get("status") == "error":
            error_msg = response.get('message', 'Unknown error')
            print(f"NewsAPI Error: {error_msg}")
            return []
        
        articles = response.get("articles", [])
        print(f"Found {len(articles)} articles")
        
        # Simplify article data
        simplified = []
        for article in articles:
            if article.get("title"):
                # Use content if available, otherwise description, otherwise just title
                content = article.get("content", "") or article.get("description", "") or article.get("title", "")
                simplified.append({
                    "title": article["title"],
                    "description": article.get("description", ""),
                    "url": article.get("url", ""),
                    "source": article.get("source", {}).get("name", "Unknown"),
                    "published": article.get("publishedAt", ""),
                    "content": f"{article['title']} {content}".strip(),
                    "author": article.get("author", ""),
                    "urlToImage": article.get("urlToImage", "")
                })
        
        print(f"Returning {len(simplified)} simplified articles")
        return simplified
    except Exception as e:
        print(f"Error fetching news: {e}")
        import traceback
        traceback.print_exc()
        return []

def get_news_sources(api_key: str, category: str = "", language: str = "en", country: str = "") -> List[Dict]:
    """Get available news sources from NewsAPI."""
    try:
        from newsapi import NewsApiClient
        
        newsapi = NewsApiClient(api_key=api_key)
        
        params = {'language': language}
        if category:
            params['category'] = category
        if country:
            params['country'] = country
            
        response = newsapi.get_sources(**params)
        
        if response.get("status") == "error":
            print(f"NewsAPI Sources Error: {response.get('message', 'Unknown error')}")
            return []
        
        sources = response.get("sources", [])
        return [{"id": s["id"], "name": s["name"], "category": s.get("category", ""), "country": s.get("country", "")} for s in sources]
    except Exception as e:
        print(f"Error fetching sources: {e}")
        return []

def get_fact_check_links(query: str) -> List[Tuple[str, str]]:
    q = clean_text(query)[:256]
    encoded = q.replace(" ", "+")
    return [
        ("Google Fact Check Explorer", f"https://toolbox.google.com/factcheck/explorer/search/{encoded};hl=en"),
        ("Google News Search", f"https://www.google.com/search?q={encoded}+site:news.google.com"),
        ("General Google Search", f"https://www.google.com/search?q={encoded}"),
        ("Bing News Search", f"https://www.bing.com/news/search?q={encoded}"),
    ]
